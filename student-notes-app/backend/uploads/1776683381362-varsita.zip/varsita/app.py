from flask import Flask, render_template, request
import pandas as pd
import re
import string
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

app = Flask(__name__)

def clean_text(text):
    text = str(text).lower()
    text = re.sub(r'[\"\'`]', '', text)
    text = re.sub(f"[{string.punctuation}]", "", text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()

# Load data
fake = pd.read_csv("Fake.csv")
true = pd.read_csv("True.csv")

fake["label"] = 0
true["label"] = 1

data = pd.concat([fake, true])

# Lookups
title_lookup = {}
text_lookup = {}

for _, row in data.iterrows():
    title_lookup[clean_text(row["title"])] = row["label"]
    text_lookup[clean_text(row["text"])] = row["label"]

# Prepare ML
data["content"] = data["title"] + " " + data["text"]
data["content"] = data["content"].apply(clean_text)

X = data["content"]
y = data["label"]

vectorizer = TfidfVectorizer(stop_words="english", max_df=0.8, min_df=2, ngram_range=(1,2))
X = vectorizer.fit_transform(X)

model = LogisticRegression(max_iter=1000)
model.fit(X, y)

# Route
@app.route("/", methods=["GET", "POST"])
def home():
    result = ""

    if request.method == "POST":
        news = request.form["news"]

        if len(news.split()) < 5:
            result = "⚠️ Please enter more detailed news"
        else:
            cleaned = clean_text(news)

            if cleaned in title_lookup:
                label = title_lookup[cleaned]
                result = "🟢 Real News (Exact Match)" if label == 1 else "🔴 Fake News (Exact Match)"

            elif cleaned in text_lookup:
                label = text_lookup[cleaned]
                result = "🟢 Real News (Exact Match)" if label == 1 else "🔴 Fake News (Exact Match)"

            else:
                vector = vectorizer.transform([cleaned])
                prediction = model.predict(vector)[0]
                confidence = model.predict_proba(vector)[0]

                if max(confidence) < 0.65:
                    result = "⚠️ Not sure"
                elif prediction == 1:
                    result = f"🟢 Real News ({confidence[1]*100:.2f}%)"
                else:
                    result = f"🔴 Fake News ({confidence[0]*100:.2f}%)"

    return render_template("index.html", result=result)
if __name__ == "__main__": 
    app.run(debug=True)